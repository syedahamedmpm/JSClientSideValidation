import React from 'react';
import * as http from '../../api/api'
import {useState} from "react";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Row,
  Col,
} from "reactstrap";

const Register = (props) => {
	
	const[profileAdd,setProfileAdd]=useState({
		firstName:'',
		lastName:'',
		email:'',
		password:'',
		adminType:''
	})
	 function handleChangeAdd (e){
		 const updateProfileAdd = {
			 ...profileAdd,
			[e.target.name]:e.target.value
		 }
		
		setProfileAdd(updateProfileAdd)
		console.log(setProfileAdd)
	}
	function handleSubmitAddProf(e){
		e.preventDefault();
		if(!profileAdd.firstName){
			toast.error("Enter First Name")
		}elseif(!profileAdd.lastName){
			
		}
		let body={
			firstName:profileAdd.firstName,
			lastName:profileAdd.lastName,
			email:profileAdd.email,
			password:profileAdd.password,
			adminType : "SuperAdmin"
		}
		http
		.adminPost(body,"adminAdd")
		.then((resp)=>resp.json())
		.then(function(data){
			//console.log(data)
			if(data.success){
				toast.success(data.message)
				setProfileAdd({
					firstName:"",
            lastName:"",
            email:"",
            phone:"",
            password:"",
            adminType:"",
				})
				props.history.push("/auth/login");
			}
			else{
          toast.error(data.messege)
        }
		})
	}
  return (
    <>
      <Col lg="6" md="8">
        <Card className="bg-secondary shadow border-0">
          <CardBody className="px-lg-5 py-lg-5">
            <Form role="form" onSubmit={handleSubmitAddProf}>
			<Row>
                <Col sm="12" md="6" lg="6">
              <FormGroup>
                <InputGroup className="input-group-alternative mb-3">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-hat-3" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input placeholder="First Name" type="text"
					name="firstName"
					value={profileAdd?.firstName}
					onChange={handleChangeAdd}
				  />
                </InputGroup>
              </FormGroup>
			  </Col>
			  <Col sm="12" md="6" lg="6">
              <FormGroup>
                <InputGroup className="input-group-alternative mb-3">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-hat-3" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input placeholder="Last Name" type="text"
					name="lastName"
					value={profileAdd?.lastName}
					onChange={handleChangeAdd}
				  />
                </InputGroup>
              </FormGroup>
			  </Col>
			  </Row>
			  <FormGroup>
                <InputGroup className="input-group-alternative mb-3">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-email-83" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Email"
                    type="email"
					name="email"
					value={profileAdd?.email}
                    autoComplete="new-email"
					onChange={handleChangeAdd}
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup>
                <InputGroup className="input-group-alternative">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-lock-circle-open" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Password"
                    type="password"
					name="password"
					value={profileAdd?.password}
                    autoComplete="new-password"
					onChange={handleChangeAdd}
                  />
                </InputGroup>
              </FormGroup>
              
              
              <div className="text-center">
                <Button className="mt-4" color="primary" type="submit">
                  Create account
                </Button>
              </div>
            </Form>
          </CardBody>
        </Card>
      </Col>
    </>
  );
};

export default Register;
