const baseUrl = "https://jba-nodejs.herokuapp.com/" //heroku


export function adminPost(body,url){
	return fetch(baseUrl + url,{
		method: "POST",
		headers: {
        "content-type": "application/json",
        
      },
	  body: JSON.stringify({
        ...body,
      }),
	});
	}