
import React, { useState,useEffect } from "react";

// reactstrap components
import {
  Badge,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Label,
  FormGroup,
  Input,
  Container,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  Col,
  Button,
  ModalFooter,
  UncontrolledTooltip,
  TabContent, TabPane, Nav, NavItem, NavLink,
  Spinner,
} from "reactstrap";
// core components
import Header from "components/Headers/Header.js";
import * as http from '../../api/api'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import classnames from 'classnames';
// import image from '../../assets/img/JBA/paste.png'

const baseUrl = http.url()

const ProjectImg = (props) => {

const [search, setSearch] = useState("")
const [projectDetail, setProjectDetails] = useState({})
const [image, setImage] = useState()
const [selectedImg, setSelectedImg] = useState("")
const [isLoading,setIsLoading] = useState(false)
const [project, setProject] = useState({
    catagory:"",
    name:""
})
const [projectAdd, setProjectAdd] = useState({
  catagory:"",
  name:""
})
const [projectList,setProjectList] = useState([])
const [projectInteriorList,setProjectInteriorList] = useState([])
const [projectExteriorList,setProjectExteriorList] = useState([])
const [projectConsultantList,setProjectConsultantList] = useState([])
const [projectPlanList,setProjectPlanList] = useState([])
const [imgModal,setImgModel] = useState(false)
const [detailModal,setDetailModel] = useState(false)
const [activeTab, setActiveTab] = useState('All');

useEffect(() => {
     allList();
  }, []);
  function allList(){
    getAllProjects();
    getPlanProjects();
    getInteriorProjects();
    getExteriorProjects();
    getConsultantProjects();
  }
  async function getAllProjects(){   
    await http
    .adminGet("getAllProject")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      setProjectList(data.projectList)
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }
  async function getInteriorProjects(){   
    await http
    .adminGet("getAllProject?catagory=interior")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      setProjectInteriorList(data.projectList)
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }

  async function getExteriorProjects(){   
    await http
    .adminGet("getAllProject?catagory=exterior")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      setProjectExteriorList(data.projectList)
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }

  async function getPlanProjects(){   
    await http
    .adminGet("getAllProject?catagory=plan")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      setProjectPlanList(data.projectList)
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }

  async function getConsultantProjects(){   
    await http
    .adminGet("getAllProject?catagory=consultant")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      setProjectConsultantList(data.projectList)
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }

const toggle = tab => {
  if(activeTab !== tab) setActiveTab(tab);
  getAllProjects()
}

function imageDetail(project){
   console.log(project)
   setProjectDetails(project)
   setDetailModel(!detailModal) 
}
function handleChange(event) {
    const updateProject = {
      ...projectAdd,
      [event.target.name]: event.target.value,
    };
    setProjectAdd(updateProject);
    console.log(updateProject);
  }

  function searchChange(event) {
    // const updateSearch = {
    //   ...search,
    //   [event.target.name]: event.target.value,
    // };
    setSearch(event.target.value);
    console.log(event.target.value);
  }
function imageChange(e){
    console.log(e.target.files[0])
    setImage(e.target.files[0])
    var reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]); 
    reader.onload = (e) => { 
      var url = e.target.result;
      setSelectedImg(url)
    }
}

function submitProject(){
    // console.log(project)
    // console.log(image)
    setIsLoading(true)
    var formData = new FormData();
    formData.append("galaryImages", image);
    formData.append("name",projectAdd.name);
    formData.append("catagory",projectAdd.catagory);
    if(projectAdd.name ==""){
      toast.error("Enter the project name")
    }else if(projectAdd.catagory == ""){
      toast.error("Select the Catagory")
    }else if(selectedImg == ""){
      toast.error("Select image")
    }else{
      http 
      .postFormData("galaryImg",formData)
      .then((resp) => resp.json())
      .then(function(data){
        console.log(data)
        if(data.success){
          toast.success(data.message)
          setIsLoading(false)
          setImgModel(false)
          setSelectedImg("")
          setProjectAdd({
            name:"",
            catagory:""
          })
          setImage()
          allList()
        }else{
          toast.error(data.message)
        }
      })
    }


}

async function deleteProject(){
    console.log(projectDetail)
    setIsLoading(true)
    await http
    .adminGet("deleteGalleryImg?id="+projectDetail.id)
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      if(data.success){
        allList()
        detailOpen()
        toast.success(data.message)
        setIsLoading(false)
      }
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
}

const imgOpen = (props) => setImgModel(!imgModal) 
const detailOpen = (props) => setDetailModel(!detailModal) 
//    function onCatagoryChange(e){
//        console.log(e.target.value)
//     //    setCatagory(e.target.value)
//    }
   const {
    className
  } = props;
  return (
    <>
      <Header />
      {/* Page content */}
      <Container className="mt--7" fluid>
        {/* Table */}
        <ToastContainer />
        <Row>
          <div className="col">
            <Card className="shadow container bg-secondary"> 
              <CardHeader className="border-0">
              <Row className="align-items-center">
                  <Col xs="8">
                    <h3 className="mb-0">Project Images</h3>
                  </Col>
                  <Col className="text-right" xs="4">
                    <Button
                      color="primary"
                      size="sm"
                      onClick={imgOpen}
                    >
                      Add Image
                    </Button>
                  </Col>
                </Row>
              </CardHeader>
              <CardBody>
              <div>
      <Nav tabs>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === 'All' })}
            onClick={() => { toggle('All'); }}
          >
            All 
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === 'Interior' })}
            onClick={() => { toggle('Interior'); }}
          >
            Interior
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === 'Exterior' })}
            onClick={() => { toggle('Exterior'); }}
          >
            Exterior
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === 'Consultant' })}
            onClick={() => { toggle('Consultant'); }}
          >
            Consultant
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === 'Plan' })}
            onClick={() => { toggle('Plan'); }}
          >
            Plan
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={activeTab}>
        <TabPane tabId="All">
          <Row>
            <Col sm="12">
              <div className="mt-5">
                <Row>
                      <Col sm="12" md="6" lg="6">
                          <h4>All Projects</h4>
                      </Col>
                      <Col sm="12" md="6" lg="6">
                        <div>
                            <Input type="text" onChange={searchChange}  placeholder="Search your project" />
                        </div>
                      </Col>
                </Row>     
                 <Row>
                        {projectList.filter(data => data.name.toLowerCase().includes(search.toLowerCase())).map(function(projects){
                            return(
                                <Col sm="12" md="4" lg="3" className="mt-3" key={projects.id}>
                                    <Card onClick={()=>imageDetail(projects)}>
                                        <CardBody>
                                            <img alt={projects.name} src={baseUrl+projects.image} height="185" width="185" />
                                        </CardBody>
                                        <CardFooter>
                                            {projects.name}
                                        </CardFooter>
                                    </Card>
                                </Col>
                            )
                        }
                        )}
                        {projectList.length == 0 ? (
                          <div className="m-5 ">
                                <h3>No Project Found</h3>
                          </div>
                        ) : null}

                 </Row>
              </div>  
            
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="Interior">
        <Row>
            <Col sm="12">
              <div className="mt-5">
                <Row>
                      <Col sm="12" md="6" lg="6">
                          <h4>Interior</h4>
                      </Col>
                      <Col sm="12" md="6" lg="6">
                        <div>
                            <Input type="text" onChange={searchChange}  placeholder="Search your project" />
                        </div>
                      </Col>
                </Row>     
                 <Row>
                        {projectInteriorList.filter(data => data.name.toLowerCase().includes(search.toLowerCase())).map(function(projects){
                            return(
                                <Col sm="12" md="4" lg="3" className="mt-3" key={projects.id}>
                                    <Card onClick={()=>imageDetail(projects)}>
                                        <CardBody>
                                            <img alt={projects.name} src={baseUrl+projects.image} height="185" width="185" />
                                        </CardBody>
                                        <CardFooter>
                                            {projects.name}
                                        </CardFooter>
                                    </Card>
                                </Col>
                            )
                        }
                        )}
                        {projectInteriorList.length == 0 ? (
                          <div className="m-5 ">
                                <h3>No Project Found</h3>
                          </div>
                        ) : null}

                 </Row>
              </div>  
            
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="Exterior">
        <Row>
            <Col sm="12">
              <div className="mt-5">
                <Row>
                      <Col sm="12" md="6" lg="6">
                          <h4>Exterior</h4>
                      </Col>
                      <Col sm="12" md="6" lg="6">
                        <div>
                            <Input type="text" onChange={searchChange}  placeholder="Search your project" />
                        </div>
                      </Col>
                </Row>     
                 <Row>
                        {projectExteriorList.filter(data => data.name.toLowerCase().includes(search.toLowerCase())).map(function(projects){
                            return(
                                <Col sm="12" md="4" lg="3" className="mt-3" key={projects.id}>
                                    <Card onClick={()=>imageDetail(projects)}>
                                        <CardBody>
                                            <img alt={projects.name} src={baseUrl+projects.image} height="185" width="185" />
                                        </CardBody>
                                        <CardFooter>
                                            {projects.name}
                                        </CardFooter>
                                    </Card>
                                </Col>
                            )
                        }
                        )}
                        {projectExteriorList.length == 0 ? (
                          <div className="m-5 ">
                                <h3>No Project Found</h3>
                          </div>
                        ) : null}

                 </Row>
              </div>  
            
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="Consultant">
        <Row>
            <Col sm="12">
              <div className="mt-5">
                <Row>
                      <Col sm="12" md="6" lg="6">
                          <h4>Consultant</h4>
                      </Col>
                      <Col sm="12" md="6" lg="6">
                        <div>
                            <Input type="text" onChange={searchChange}  placeholder="Search your project" />
                        </div>
                      </Col>
                </Row>     
                 <Row>
                        {projectConsultantList.filter(data => data.name.toLowerCase().includes(search.toLowerCase())).map(function(projects){
                            return(
                                <Col sm="12" md="4" lg="3" className="mt-3" key={projects.id}>
                                    <Card onClick={()=>imageDetail(projects)}>
                                        <CardBody>
                                            <img alt={projects.name} src={baseUrl+projects.image} height="185" width="185" />
                                        </CardBody>
                                        <CardFooter>
                                            {projects.name}
                                        </CardFooter>
                                    </Card>
                                </Col>
                            )
                        }
                        )}
                        {projectConsultantList.length == 0 ? (
                          <div className="m-5 ">
                                <h3>No Project Found</h3>
                          </div>
                        ) : null}

                 </Row>
              </div>  
            
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="Plan">
        <Row>
            <Col sm="12">
              <div className="mt-5">
                <Row>
                      <Col sm="12" md="6" lg="6">
                          <h4>Plan</h4>
                      </Col>
                      <Col sm="12" md="6" lg="6">
                        <div>
                            <Input type="text" onChange={searchChange}  placeholder="Search your project" />
                        </div>
                      </Col>
                </Row>     
                 <Row>
                        {projectPlanList.filter(data => data.name.toLowerCase().includes(search.toLowerCase())).map(function(projects){
                            return(
                                <Col sm="12" md="4" lg="3" className="mt-3" key={projects.id}>
                                    <Card onClick={()=>imageDetail(projects)}>
                                        <CardBody>
                                            <img alt={projects.name} src={baseUrl+projects.image} height="185" width="185" />
                                        </CardBody>
                                        <CardFooter>
                                            {projects.name}
                                        </CardFooter>
                                    </Card>
                                </Col>
                            )
                        }
                        )}
                        {projectPlanList.length == 0 ? (
                          <div className="m-5 ">
                                <h3>No Project Found</h3>
                          </div>
                        ) : null}

                 </Row>
              </div>  
            
            </Col>
          </Row>
        </TabPane>
      </TabContent>
    </div>
              </CardBody>
          
              <CardFooter className="py-4">
         
              </CardFooter>
            </Card>
          </div>
        </Row>
        {/* Dark table */}
       
      </Container>
      <Modal isOpen={imgModal} toggle={imgOpen} className={className}>
        <ModalHeader toggle={imgOpen}>Add Image</ModalHeader>
        <ModalBody className="bg-secondary shadow">
            <Row>
                <Col sm="12" md="6" lg="6">
                        <FormGroup>
                            <Label for="exampleSelect">Select Catagory</Label>
                            <Input type="select" name="catagory" value={projectAdd.catagory} onChange={handleChange}>
                            <option selected> --Select Catagory--</option>    
                            <option value="plan" >Plan</option>
                            <option value="interior" >Interior</option>
                            <option value="exterior" >Exterior</option>
                            <option value="consultant" >Consultant</option>
                            </Input>
                        </FormGroup>
                        <FormGroup>
                            <Label for="exampleEmail">Image Name</Label>
                            <Input type="text" name="name" value={projectAdd.name} onChange={handleChange} placeholder="Enter Name of Image" />
                        </FormGroup>
                        <FormGroup>
                            <Label for="exampleEmail">Image Name</Label>
                            <input hidden id="fileUpload" type="file" name="profileImg" onChange={imageChange} accept="image/*" />
                            <div>
                                    <label htmlFor="fileUpload">
                                    <p>Click Here to Upload Image</p>
                                    </label>
                            </div>
                            {/* <Input type="text" name="imgName" id="exampleEmail" placeholder="Enter Name of Image" /> */}
                        </FormGroup>
                </Col>
                <Col  sm="12" md="6" lg="6">
                    <img src={
                       selectedImg == ""
                       ? require("../../assets/img/JBA/paste.png").default                         
                       : selectedImg
                     
                    } width="100%" />
                
                </Col>
            </Row>
           
 
        </ModalBody>
        <ModalFooter>

          <Button color="primary" onClick={submitProject} disabled={isLoading}> {isLoading ? (<Spinner size="sm" color="dark" />) : null }Add Image</Button>{' '}
          <Button color="secondary" onClick={imgOpen}>Cancel</Button>
        </ModalFooter>
      </Modal>


      <Modal isOpen={detailModal} toggle={detailOpen} className={className}>
        <ModalHeader toggle={detailOpen}>Project Detail</ModalHeader>
        <ModalBody className="bg-secondary shadow">
            
             <img src={baseUrl+projectDetail.image}      width="100%"/>  
             <div className="mt-3">
                 <h4>Project Name : {projectDetail.name}</h4>
             </div>
             <div className="mt-3">
                 <h4>Catagory : {projectDetail.catagory}</h4>
             </div>
 
        </ModalBody>
        <ModalFooter>
          <Button color="danger" onClick={deleteProject}>Delete</Button>{' '}
          <Button color="secondary" onClick={detailOpen}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </>
  );
};

export default ProjectImg;
