import React, { useState,useEffect } from "react";
import * as http from '../../api/api'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  Container,
  Row,
  Col,
  Spinner,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Table
} from "reactstrap";
// core components
import UserHeader from "components/Headers/UserHeader.js";

const Profile = (props) => {

  const {
    buttonLabel,
    className
  } = props;
  const baseUrl = http.url()
  const [profileData,setProfileData] = useState({
    firstName:"",
    lastName:"",
    email:"",
    phone:null,
    adminType:"",
    profileImage:""
  })
  const [profImg, setProfImg] = useState("") 
  const [profileAdd,setProfileAdd] = useState({
    firstName:"",
    lastName:"",
    email:"",
    phone:null,
    password:""
  })
  const [contactDetail,setContactDetail] = useState({
    address:"",
    city:"",
    state:"",
    country:"",
    email:"",
    phone:"",
    about:"",
  })

  const [resetPassword,setResetPassword] = useState({
    email:profileData.email,
    password:"",
    resetPassword:""
  })
  const [isLoading,setIsLoading] = useState(false)
  const [modal, setModal] = useState(false);
  const [imgModal,setImgModel] = useState(false)
  const [selectedImg, setSelectedImg] = useState()
  const [adminList, setAdminList] = useState([])

  useEffect(() => {
    getProfile();
    getAdminList();
  }, []);

  useEffect(() => {
    let token = localStorage.getItem("token");
    if(!token){
      props.history.push("/auth/login");
    }else{
      getContactDetails();
    }
   

  }, []);

  const toggle = () => setModal(!modal);

  const imgOpen = () => setImgModel(!imgModal) 
  function handleSubmitAddProf(event){
    event.preventDefault()
    console.log(profileAdd)
    http 
    .adminPost(profileAdd,"adminAdd")
    .then((resp) => resp.json())
    .then(function(data){
      console.log(data)
      if(data.success){
        toast.success(data.message)
        toggle()
      }else{
        toast.error(data.message)
      }
    })
  }

  function handleSubmit(event){
    setIsLoading(true)
    event.preventDefault()
    console.log(profileData)
    http 
    .adminPost(profileData,"updateAdmin?id="+profileData.id)
    .then((resp) => resp.json())
    .then(function(data){
      console.log(data)
      if(data.success){
        setIsLoading(false)
        toast.success(data.message)
        getProfile()
      }else{
        toast.error(data.messege)
      }
    })
  }
  function handleResetPassSubmit(event){
    event.preventDefault()
     var body ={
       email : profileData.email,
       password : resetPassword.password,
       resetPassword : resetPassword.resetPassword
     }
     console.log(body)
  
    http 
    .adminPost(body,"changePassword")
    .then((resp) => resp.json())
    .then(function(data){
      console.log(data)
      if(data.success){
        toast.success(data.message)
        getContactDetails()
        setTimeout(() => {
          setResetPassword({
            password:"",
            resetPassword:""
          })
        }, 1000);
     
        // resetPassword.reset()
         
        // document.getElementById("reset-password").reset()

      }else{
        toast.error(data.message)
      }
    })
    
  }
  function handleSubmitContact(event){
  
    event.preventDefault()
    console.log(contactDetail)
    http 
    .adminPost(contactDetail,"contactAdd")
    .then((resp) => resp.json())
    .then(function(data){
      console.log(data)
      if(data.success){
        toast.success(data.message)
        getContactDetails()
      }else{
        toast.error(data.messege)
      }
    })
  }

  function handleChange(event) {
    const updateProfileData = {
      ...profileData,
      [event.target.name]: event.target.value,
    };
    setProfileData(updateProfileData);
    console.log(updateProfileData);
  }

  function handleChangePass(event) {
    const updateResetPass = {
      ...resetPassword,
      [event.target.name]: event.target.value,
    };
    setResetPassword(updateResetPass);
    // console.log(updateResetPass);
  }

  function handleChangeAdd(event) {
    const updateProfileAdd = {
      ...profileAdd,
      [event.target.name]: event.target.value,
    };
    setProfileAdd(updateProfileAdd);
    // console.log(updateProfileAdd);
  } 

  function handleChangeContact(event) {
    const updateContactDetail = {
      ...contactDetail,
      [event.target.name]: event.target.value,
    };
    setContactDetail(updateContactDetail);
  }

 function imgChange(e){
   console.log(e.target.files[0])
   var file = e.target.files[0]
   var formData = new FormData();
   formData.append("profileImage", file);
   
   http 
   .postFormData("profileUpload?id="+profileData.id,formData)
   .then((resp) => resp.json())
   .then(function(data){
     console.log(data)
     if(data.success){
       toast.success(data.message)
       getProfile()
     }else{
       toast.error(data.messege)
     }
   })
 }

 function removeProfilePictur(){
  http 
  .adminPost("","profileRemove?id="+profileData.id)
  .then((resp) => resp.json())
  .then(function(data){
    console.log(data)
    if(data.success){
      setIsLoading(false)
      toast.success(data.message)
      getProfile()
    }else{
      toast.error(data.messege)
    }
  })
 }

  async function getContactDetails(){
     await http
     .adminGet("contactDetail")
     .then((resp) => resp.json())
     .then(function (data) {
       console.log("data", data);
      
       setContactDetail({
         address: data.contact.address,
         city:data.contact.city,
         email:data.contact.email,
         phone:data.contact.phone,
         state:data.contact.state,
         country:data.contact.country,
         about:data.contact.about
       });
     })
     .catch(function (error) {
       console.log(error);
       return null;
     });
    }

    
  
    async function getProfile(){
   let profileId = (localStorage?.getItem("id")?.replace(/['"]+/g, ''))
  
    await http
    .adminGet("myProfile?id="+profileId)
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data);
      var profile = data.profile
     
      setProfileData({
        firstName: profile.firstName,
        lastName:profile.lastName,
        email:profile.email,
        phone:profile.phone,
        id:profile.id,
        adminType:profile.adminType,
        profileImage:profile.profileImageUrl
        
      
      });
      getAdminList()
      // setTimeout(() => {
      //   console.log(profileData)
      // }, 5000);
  
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }
  async function getAdminList(){   
     await http
     .adminGet("admin")
     .then((resp) => resp.json())
     .then(function (data) {
       console.log("data", data);

       setAdminList(data.adminList)

       console.log(adminList)
     })
     .catch(function (error) {
       console.log(error);
       return null;
     });
   }
  return (
    <>
     
      <UserHeader
      profileData={profileData}
      />
      {/* Page content */}
      <Container className="mt--7" fluid>
      <ToastContainer />
        <Row>
          <Col className="order-xl-2 mb-5 mb-xl-0" xl="4">
            <Card className="card-profile shadow">
              <Row className="justify-content-center">
                <Col className="order-lg-2" lg="3">
                  <div className="card-profile-image">
                    <a onClick={imgOpen}>
                      
                      <img
                        alt="..."
                        className="rounded-circle"
                        src={
                          profileData?.profileImage == ""
                              ? require("../../assets/img/JBA/user.png").default                         
                              : baseUrl+profileData?.profileImage

                        }
                        height="200"
                        width="200"
                      />
                    </a>
                  </div>
                </Col>
              </Row>
              <CardHeader className="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
       
              </CardHeader>
              <CardBody className="pt-0 pt-md-4">
          
              <input hidden id="fileUpload" type="file" name="profileImg" onChange={imgChange} accept="image/*" />
                <Row>
                  <div className="col">
                    <div className="card-profile-stats d-flex justify-content-center mt-md-5">
                     <div>
                            <label htmlFor="fileUpload">
                               <p>Upload Image</p>
                            </label>
                     </div>
                     <div>
                        <p onClick={removeProfilePictur}>Remove Image</p>
                     </div>
                      {/* <div>
                        <span className="heading">22</span>
                        <span className="description">Friends</span>
                      </div>
                      <div>
                        <span className="heading">10</span>
                        <span className="description">Photos</span>
                      </div>
                      <div>
                        <span className="heading">89</span>
                        <span className="description">Comments</span>
                      </div> */}
                    </div>
                  </div>
                </Row>
                <div className="text-capitalize">
                  <h3 className="text-center">
                    {profileData.firstName} {profileData.lastName}
                    
                  </h3>

                  <div className="h5 font-weight-300 text-center">
                    <i className="location_pin mr-2" />
                    <p>{contactDetail.address} {contactDetail.city}</p>
                    {contactDetail.state}, {contactDetail.country}
                  </div>
             
                  <hr className="my-4" />
                  <h6 className="heading-small text-muted mb-4">
                    Change Password
                  </h6>
                  <Form onSubmit={handleResetPassSubmit} 
                  // id="reset-password"
                  >
                  <Row>
                      <Col lg="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-first-name"
                          >
                            Current Password
                          </label>
                          <Input
                            className="form-control-alternative"
                     
                            id="input-first-name"
                            placeholder="Current Password"
                            type="password"
                            onChange={handleChangePass}
                            name="password"
                            value={resetPassword.password}

                          />
                        </FormGroup>
                      </Col>
                      <Col lg="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-last-name"
                          >
                            New Password
                          </label>
                          <Input
                            className="form-control-alternative"
  
                            id="input-last-name"
                            placeholder="New Password"
                            type="password"
                            onChange={handleChangePass}
                            name="resetPassword"
                            value={resetPassword.resetPassword}
                          />
                        </FormGroup>
                        <Button
                      color="primary"
                      size="sm">
                         Submit
                      </Button>
                      </Col>
             
                    </Row>
                  </Form>
                  
                </div>
              </CardBody>
            </Card>

          </Col>
          <Col className="order-xl-1" xl="8">
            <Card className="bg-secondary shadow">
              <CardHeader className="bg-white border-0">
                <Row className="align-items-center">
                  <Col xs="8">
                    <h3 className="mb-0">My account</h3>
                  </Col>
                  <Col className="text-right" xs="4">
                 
                  </Col>
                </Row>
              </CardHeader>
              <CardBody>
                <Form onSubmit = {handleSubmit}>
                  <h6 className="heading-small text-muted mb-4">
                    User information
                  </h6>
                  <div className="pl-lg-4">
                    <Row>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-username"
                          >
                            Mobile Number
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={profileData.phone}
                            id="input-username"
                            placeholder="Username"
                            type="text"
                            onChange={handleChange}
                            name="phone"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-email"
                          >
                            Email address
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-email"
                            placeholder="jesse@example.com"
                            type="email"
                            defaultValue={profileData.email}
                            onChange={handleChange}
                            name="email"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-first-name"
                          >
                            First name
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={profileData.firstName}
                            id="input-first-name"
                            placeholder="First name"
                            type="text"
                            onChange={handleChange}
                            name="firstName"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-last-name"
                          >
                            Last name
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={profileData.lastName}
                            id="input-last-name"
                            placeholder="Last name"
                            type="text"
                            onChange={handleChange}
                            name="lastName"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <div>
                      {isLoading ? (
                    <Button
                    className="text-center"
                    color="primary"
                    disabled={true}
                    size="sm"
                  ><Spinner size="sm" color="dark" />
                    Update
                  </Button>
                      ) : (
                        <Button
                        className="text-center"
                        color="primary"
                        size="sm"
                      >
                        Update
                      </Button>
                      ) }
                
                    </div>
                   
                  </div>
                  </Form>
                  <Form onSubmit={handleSubmitContact}>
                  <hr className="my-4" />
                  {/* Address */}
                  <h6 className="heading-small text-muted mb-4">
                    Contact information And About Us
                  </h6>
                  <div className="pl-lg-4">
                  <Row>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-username"
                          >
                            Mobile Number
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={contactDetail.phone}
                            id="input-username"
                            placeholder="Username"
                            type="text"
                            onChange={handleChangeContact}
                            name="phone"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-email"
                          >
                            Email address
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-email"
                            placeholder="jesse@example.com"
                            type="email"
                            defaultValue={contactDetail.email}
                            onChange={handleChangeContact}
                            name="email"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-address"
                          >
                            Address
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={contactDetail.address}
                            id="input-address"
                            placeholder="Home Address"
                            type="text"
                            name="address"
                            onChange={handleChangeContact}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col lg="4">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-city"
                          >
                            City
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={contactDetail.city}
                            id="input-city"
                            placeholder="City"
                            type="text"
                            name="city"
                            onChange={handleChangeContact}
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="4">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-country"
                          >
                            State
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-postal-code"
                            placeholder="Postal code"
                            type="text"
                            defaultValue={contactDetail.state}
                            name="state"
                            onChange={handleChangeContact}
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="4">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-country"
                          >
                            Country
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue={contactDetail.country}
                            id="input-country"
                            placeholder="Country"
                            type="text"
                            name="country"
                            onChange={handleChangeContact}
                          />
                        </FormGroup>
                      </Col>
              
                    </Row>
                  </div>
                  <div className="pl-lg-4">
                    <FormGroup>
                      <label>About Me</label>
                      <Input
                        className="form-control-alternative"
                        placeholder="A few words about you ..."
                        rows="4"
                        defaultValue={contactDetail.about}
                        type="textarea"
                        onChange={handleChangeContact}
                        name="about"
                      />
                    </FormGroup>
                    <Button
                    className="text-center"
                    color="primary"
                    size="sm"
                  >
                    Update
                  </Button>
                  </div>
            
                  
                </Form>
              </CardBody>
            </Card>
           {profileData.adminType == "SuperAdmin" ? (
            <Card className="bg-secondary shadow mt-5">
              <CardHeader className="bg-white border-0">
                <Row className="align-items-center">
                  <Col xs="8">
                    <h3 className="mb-0">Admin List</h3>
                  </Col>
                  <Col className="text-right" xs="4">
                    <Button
                      color="primary"
                      size="sm"
                      onClick={toggle}
                    >
                      Add Admin
                    </Button>
                  </Col>
                </Row>
              </CardHeader>
              <CardBody>
           
              <Table className="align-items-center table-flush" responsive>
                <thead className="thead-light">
                  <tr>
                    <th>S.No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Email</th>
                    

                  </tr>
                </thead>
                <tbody>
                  {adminList.map(function(data,index){
                    // console.log(data)
                    return(
                      <tr key={data.id}>
                      <td>{index+1}</td>
                      <td className="text-capitalize">{data.firstName} {data.lastName}</td>
                      <td>{data.phone}</td>
                      <td>{data.email}</td>

                    </tr>
                    )
                  
                  })}
                  
                </tbody>
              </Table>
              </CardBody>
            </Card>
           ) : null}
            
          </Col>
        </Row>
      </Container>
      <div>
      
      <Modal isOpen={modal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Add Admin</ModalHeader>
        <ModalBody className="bg-secondary shadow">
          <Form onSubmit={handleSubmitAddProf}>
          <Row>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-first-name"
                          >
                            First name
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-first-name"
                            placeholder="First name"
                            type="text"
                            onChange={handleChangeAdd}
                            name="firstName"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="6">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-last-name"
                          >
                            Last name
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-last-name"
                            placeholder="Last name"
                            type="text"
                            onChange={handleChangeAdd}
                            name="lastName"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                   <Row>
                      <Col lg="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-username"
                          >
                            Mobile Number
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-username"
                            placeholder="Username"
                            type="text"
                            onChange={handleChangeAdd}
                            name="phone"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-email"
                          >
                            Email address
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-email"
                            placeholder="jesse@example.com"
                            type="email"
                            onChange={handleChangeAdd}
                            name="email"
                          />
                        </FormGroup>
                      </Col>
                      <Col lg="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-email"
                          >
                            Password
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-email"
                            placeholder="Password"
                            type="password"
                            onChange={handleChangeAdd}
                            name="password"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Button
                    className="text-center"
                    color="primary"
                    size="sm"
                  >
                    Add
                  </Button>

          </Form>
        
        </ModalBody>
        {/* <ModalFooter>
          <Button color="primary" onClick={toggle}>Do Something</Button>{' '}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter> */}
      </Modal>
    </div>

    <div>
      
      <Modal isOpen={imgModal} toggle={imgOpen} className={className}>
        <ModalHeader toggle={imgOpen}>Profile Picture</ModalHeader>
        <ModalBody className="bg-secondary shadow">
        <div style={{textAlign:"center"}}>
                      <img
                        alt="..."
                        // className="rounded-circle"
                        src={
                          profileData?.profileImage == ""
                              ? require("../../assets/img/JBA/user.png").default                         
                              : baseUrl+profileData?.profileImage
                        }
                        width="100%"
                      />
              
                  </div>
        </ModalBody>
        {/* <ModalFooter>
          <Button color="primary" onClick={toggle}>Do Something</Button>{' '}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter> */}
      </Modal>
    </div>
    </>
  );
};

export default Profile;
