import React, { useState,useEffect } from "react";
import * as http from '../../api/api'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import logo from '../../assets/img/JBA/JBA.jpg'
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Row,
  Col,
} from "reactstrap";

const Register = (props) => {


  const [profileAdd,setProfileAdd] = useState({
    firstName:"",
    lastName:"",
    email:"",
    phone:"",
    password:"",
    adminType:""
  })

  useEffect(() => {
    getAdminList();
  }, []);
  
  async function getAdminList(){   
    await http
    .adminGet("adminCount")
    .then((resp) => resp.json())
    .then(function (data) {
      console.log("data", data.adminList);
      if(data.adminList != 0){
        props.history.push("/auth/login");
      }
    })
    .catch(function (error) {
      console.log(error);
      return null;
    });
  }

  function handleSubmitAddProf(event){
    event.preventDefault()
    console.log(profileAdd)
    if(!profileAdd.firstName){
      toast.error("Enter First Name")
    }else if(!profileAdd.lastName){
      toast.error("Enter Last Name")
    }else if(!profileAdd.email){
      toast.error("Enter Email")
    }else if(!profileAdd.phone){
      toast.error("Enter Phone No")
    }else if(!profileAdd.password){
      toast.error("Enter Password")
    }else{
      let body = {
        firstName : profileAdd.firstName,
        lastName : profileAdd.lastName,
        email : profileAdd.email,
        phone : profileAdd.phone,
        password : profileAdd.password,
        adminType : "SuperAdmin"
      }
      http 
      .adminPost(body,"adminAdd")
      .then((resp) => resp.json())
      .then(function(data){
        // console.log(data)
        if(data.success){
          toast.success(data.message)
          setProfileAdd({
            firstName:"",
            lastName:"",
            email:"",
            phone:"",
            password:"",
            adminType:"",
          })
          props.history.push("/auth/login");
        }else{
          toast.error(data.messege)
        }
      })
    }
  
  }
  
  function handleChangeAdd(event) {
    const updateProfileAdd = {
      ...profileAdd,
      [event.target.name]: event.target.value,
    };
    setProfileAdd(updateProfileAdd);
    console.log(updateProfileAdd);
  } 
  return (
    <>
      <Col lg="6" md="8">
      <ToastContainer />
        <Card className="bg-secondary shadow border-0">
          <CardHeader className="bg-transparent pb-5">
            {/* <div className="text-muted text-center mt-2 mb-4">
              <small>Sign up</small>
            </div> */}
            <div className="text-muted text-center mt-1 mb-1">
              {/* <small>Sign in </small> */}
              <img src={logo} height="80" />
            </div>
          </CardHeader>
          <CardBody className="px-lg-5 py-lg-5">
            {/* <div className="text-center text-muted mb-4">
              <small>Or sign up with credentials</small>
            </div> */}
            <Form role="form" onSubmit={handleSubmitAddProf}>
              <Row>
                <Col sm="12" md="6" lg="6">
                <FormGroup>
                  <InputGroup className="input-group-alternative mb-3">
                    <InputGroupAddon addonType="prepend">
                      <InputGroupText>
                        <i className="ni ni-hat-3" />
                      </InputGroupText>
                    </InputGroupAddon>
                    <Input placeholder="First Name" type="text" name="firstName" value={profileAdd?.firstName} onChange={handleChangeAdd}/>
                  </InputGroup>
                </FormGroup>
                </Col>
                <Col sm="12" md="6" lg="6">
                  <FormGroup>
                    <InputGroup className="input-group-alternative mb-3">
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="ni ni-hat-3" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input placeholder="Last Name" type="text" name="lastName" value={profileAdd?.lastName} onChange={handleChangeAdd}/>
                    </InputGroup>
                  </FormGroup>
                </Col>
              </Row>

              <FormGroup>
                <InputGroup className="input-group-alternative mb-3">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-email-83" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Email"
                    type="email"
                    autoComplete="new-email"
                    name="email"
                    value={profileAdd?.email}
                    onChange={handleChangeAdd}
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup>
                <InputGroup className="input-group-alternative mb-3">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-email-83" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Phone"
                    type="number"
                    name="phone"
                    onChange={handleChangeAdd}
                    value={profileAdd?.phone}
                    // autoComplete="new-email"
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup>
                <InputGroup className="input-group-alternative">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-lock-circle-open" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Password"
                    type="password"
                    autoComplete="new-password"
                    name="password"
                    value={profileAdd?.password}
                    onChange={handleChangeAdd}
                  />
                </InputGroup>
              </FormGroup>
              {/* <div className="text-muted font-italic">
                <small>
                  password strength:{" "}
                  <span className="text-success font-weight-700">strong</span>
                </small>
              </div> */}
              {/* <Row className="my-4">
                <Col xs="12">
                  <div className="custom-control custom-control-alternative custom-checkbox">
                    <input
                      className="custom-control-input"
                      id="customCheckRegister"
                      type="checkbox"
                    />
                    <label
                      className="custom-control-label"
                      htmlFor="customCheckRegister"
                    >
                      <span className="text-muted">
                        I agree with the{" "}
                        <a href="#pablo" onClick={(e) => e.preventDefault()}>
                          Privacy Policy
                        </a>
                      </span>
                    </label>
                  </div>
                </Col>
              </Row> */}
              <div className="text-center">
                <Button className="mt-4" color="primary" type="submit">
                  Create account
                </Button>
              </div>
            </Form>
          </CardBody>
        </Card>
      </Col>
    </>
  );
};

export default Register;
