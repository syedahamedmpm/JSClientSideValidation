// import React from "react";

// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Row,
  Col,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import * as http from '../../api/api'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import logo from '../../assets/img/JBA/JBA.jpg'

function Login(props){
const [loginData,setLoginData] = useState({
  email :"",
  password : ""
})
const [adminCound, setAdminCound] = useState(0)


useEffect(() => {
  getAdminList();
}, []);

async function getAdminList(){   
  await http
  .adminGet("adminCount")
  .then((resp) => resp.json())
  .then(function (data) {
    console.log("data", data);

    setAdminCound(data.adminList)

    console.log(adminCound)
  })
  .catch(function (error) {
    console.log(error);
    return null;
  });
}

  function handleChange(event) {
    console.log(event)
    const updateLoginData = {
      ...loginData,
      [event.target.name]: event.target.value,
    };
    setLoginData(updateLoginData);
    console.log(updateLoginData);
  }
  // function handleSubmit(){
  //   console.log(loginData.email)

  // }
  const register = () => {
    props.history.push("/auth/register");
  }
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // console.log(loginData)
    http
    .authPost(loginData,"signin")
    .then((resp) => resp.json())
    .then(function (data) {
      if(data.success){
        // alert("success "+data.messege)
       
        localStorage.setItem("token", data.token);
        localStorage.setItem("userDetail", JSON.stringify(data.userDetail));
        localStorage.setItem("id", JSON.stringify(data.userDetail.id));
        toast.success(data.message)
        setTimeout(() => {
          props.history.push("/admin/index");
        }, 2000);
    
      }else{
        toast.error(data.message)
        console.log(data.message)
      }
    })

  };

  return (
    <>
      <Col lg="5" md="7">
        <Card className="bg-secondary shadow border-0">
          <CardHeader className="bg-transparent pb-3">
            <div className="text-muted text-center mt-1 mb-1">
              {/* <small>Sign in </small> */}
              <img src={logo} height="80" />
            </div>
           
          </CardHeader>
          <ToastContainer />
          <CardBody className="px-lg-5 py-lg-5">
       
            <Form role="form" onSubmit = {handleSubmit}>
              <FormGroup className="mb-3">
                <InputGroup className="input-group-alternative">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-email-83" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Email"
                    name="email"
                    type="email"
                    autoComplete="new-email"
                    onChange={handleChange}
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup>
                <InputGroup className="input-group-alternative">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-lock-circle-open" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Password"
                    name="password"
                    type="password"
                    autoComplete="new-password"
                    onChange={handleChange}
                  />
                </InputGroup>
              </FormGroup>
              {/* <div className="custom-control custom-control-alternative custom-checkbox">
                <input
                  className="custom-control-input"
                  id=" customCheckLogin"
                  type="checkbox"
                />
                <label
                  className="custom-control-label"
                  htmlFor=" customCheckLogin"
                >
                  <span className="text-muted">Remember me</span>
                </label>
              </div> */}
              <div className="text-center">
                <Button className="my-4" color="primary" type="submit">
                  Sign in
                </Button>
              </div>
            </Form>
          </CardBody>
        </Card>
        <Row className="mt-3">
          <Col xs="6">
            <a
              className="text-light"
              href="#pablo"
              onClick={(e) => e.preventDefault()}
            >
              <small>Forgot password?</small>
            </a>
          </Col>
          <Col className="text-right" xs="6">
            <a
              className="text-light"
              href="#pablo"
              onClick={(e) => e.preventDefault()}
            >
              {adminCound == 0 ? (
                <small onClick={register}>Create new account</small>
              ) : null}
             
            </a>
          </Col>
        </Row>
      </Col>
    </>
  );
};

export default Login;
