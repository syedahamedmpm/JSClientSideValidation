import React, { useState,useEffect }  from "react";

// reactstrap components
import { Card, CardBody, CardTitle, Container, Row, Col } from "reactstrap";
import * as http from '../../api/api'

const Header = () => {
  const [count,setCount] = useState()

  useEffect(() => {
    getDetails();
 }, []);

  function getDetails(){

      allCount()

  }
 async function allCount(){   
  await http
  .adminGet("clientCount")
  .then((resp) => resp.json())
  .then(function (data) {
    // console.log("data", data);
   setCount(data.clientCount)

  })
  .catch(function (error) {
    console.log(error);
    return null;
  });
}
  return (
    <>
      <div className="header bg-gradient-info pb-8 pt-5 pt-md-8">
        <Container fluid>
          <div className="header-body">
            {/* Card stats */}
            <Row>
            <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Interior
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">{count?.interior.all}</span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-warning text-white rounded-circle shadow">
                          <i className="fas fa-cube" />
                        </div>
                      </Col>
                    </Row>
                    <p className="mt-3 mb-0 text-muted text-sm">
                      <span className="text-success mr-2">
                        <i className="fas fa-arrow-up" /> {count?.interior.unread}
                      </span>{" "}
                      <span className="text-nowrap">New Clients</span>
                    </p>
                  </CardBody>
                </Card>
              </Col>
              <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Exterior
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">
                          {count?.exterior.all}
                        </span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-danger text-white rounded-circle shadow">
                          <i className="fas fa-home" />
                        </div>
                      </Col>
                    </Row>
                    <p className="mt-3 mb-0 text-muted text-sm">
                      <span className="text-success mr-2">
                        <i className="fa fa-arrow-up" /> {count?.exterior.unread}
                      </span>{" "}
                      <span className="text-nowrap">New Clients</span>
                    </p>
                  </CardBody>
                </Card>
              </Col>
              
              <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Consultant
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">{count?.consultant.all}</span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-yellow text-white rounded-circle shadow">
                          <i className="fas fa-users" />
                          
                        </div>
                      </Col>
                    </Row>
                    <p className="mt-3 mb-0 text-muted text-sm">
                      <span className="text-success mr-2">
                        <i className="fas fa-arrow-up" /> {count?.consultant.unread}
                      </span>{" "}
                      <span className="text-nowrap">New Clients</span>
                    </p>
                  </CardBody>
                </Card>
              </Col>
              <Col lg="6" xl="3">
                <Card className="card-stats mb-4 mb-xl-0">
                  <CardBody>
                    <Row>
                      <div className="col">
                        <CardTitle
                          tag="h5"
                          className="text-uppercase text-muted mb-0"
                        >
                          Planning
                        </CardTitle>
                        <span className="h2 font-weight-bold mb-0">{count?.planning.all}</span>
                      </div>
                      <Col className="col-auto">
                        <div className="icon icon-shape bg-info text-white rounded-circle shadow">
                          <i className="fas fa-laptop-house" />
                          
                        </div>
                      </Col>
                    </Row>
                    <p className="mt-3 mb-0 text-muted text-sm">
                      <span className="text-success mr-2">
                        <i className="fas fa-arrow-up" /> {count?.planning.unread}
                      </span>{" "}
                      <span className="text-nowrap">New Clients</span>
                    </p>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </div>
        </Container>
      </div>
    </>
  );
};

export default Header;
